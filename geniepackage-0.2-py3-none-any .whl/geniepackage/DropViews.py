#!/usr/bin/env python
# coding: utf-8

# ## DropViews
# 
# 
# 

# In[ ]:


get_ipython().run_cell_magic('sql', '', 'DROP VIEW IF EXISTS Gold_Hiresvw;\r\nDROP VIEW IF EXISTS EventView;\r\nDROP VIEW IF EXISTS ActualEvents;\r\n\r\nDROP VIEW IF EXISTS vw_Fact_Candidacy;\r\nDROP VIEW IF EXISTS vw_DimCandidacyStatus;\r\nDROP VIEW IF EXISTS vw_DimCandidate;\r\nDROP VIEW IF EXISTS vw_DimDate;\r\nDROP VIEW IF EXISTS AllCandidates;\r\nDROP VIEW IF EXISTS HiredCandidates;\r\nDROP VIEW IF EXISTS vw_DimRequisition;\r\nDROP VIEW IF EXISTS vw_DimOffer;\r\nDROP VIEW IF EXISTS vw_Cooked_Candidacy;\r\n\r\nDROP VIEW IF EXISTS GOld_MSSvw;\r\n\r\nDROP VIEW IF EXISTS PersonnelDataView_filtered;\r\nDROP VIEW IF EXISTS PersonalInformationView_filtered;\r\nDROP VIEW IF EXISTS ProfilePositionView_filtered;\r\nDROP VIEW IF EXISTS JobInformationView_filtered;\r\n\r\nDROP VIEW IF EXISTS BubblePositions;\r\n\r\nDROP VIEW IF EXISTS Gold_Terminationsvw;\r\nDROP VIEW IF EXISTS UniqueTerminationEventsvw;\r\nDROP VIEW IF EXISTS TerminationEventMappingvw;\r\nDROP VIEW IF EXISTS MaxTerminationEventView;\r\nDROP VIEW IF EXISTS TerminationEventsvw;\r\nDROP VIEW IF EXISTS CoreIdentityInfovw;\r\n\r\nDROP VIEW IF EXISTS Gold_TransfersView;\r\nDROP VIEW IF EXISTS EventView;\r\nDROP VIEW IF EXISTS ActualEvents;\r\n\r\nDROP VIEW IF EXISTS vw_cookedCandidate;\r\n\r\nDROP VIEW IF EXISTS PosCostCenter;\r\nDROP VIEW IF EXISTS vwONBData;\r\nDROP VIEW IF EXISTS latestHRCPerson;\r\nDROP VIEW IF EXISTS latestHRCPosition;\r\nDROP VIEW IF EXISTS vwIcimsManagerInfo;\r\nDROP VIEW IF EXISTS vwCurrentStatusMapping;\r\nDROP VIEW IF EXISTS TempHRCPersonPosition;\r\nDROP VIEW IF EXISTS HRCPersonPosition;\r\nDROP VIEW IF EXISTS CookedNEOView;\r\nDROP VIEW IF EXISTS PriorReportsToDetail;\r\nDROP VIEW IF EXISTS Workflow_Position;\r\nDROP VIEW IF EXISTS Workflow_Profile;\r\n\r\nDROP VIEW IF EXISTS vwONBDataOnboarding;\r\n\r\nDROP VIEW IF EXISTS global_temp.Transaction_Position;\r\nDROP VIEW IF EXISTS global_temp.Transaction_Profile;\r\nDROP VIEW IF EXISTS global_temp.AllComment_hrcview;\r\nDROP VIEW IF EXISTS global_temp.CurrentStepComment_hrcview;\r\nDROP VIEW IF EXISTS global_temp.PreviousPositionDetails;\r\nDROP VIEW IF EXISTS Workflow_Position;\r\nDROP VIEW IF EXISTS global_temp.Transaction_PositionTemp;\r\nDROP VIEW IF EXISTS Workflow_Profile;\r\n')


#!/usr/bin/env python
# coding: utf-8

# ## GenieWrapper
# 
# 
# 

# In[ ]:


get_ipython().run_cell_magic('configure', '', '// Do not execute this cell when running in any pool apart from geniemedium pool\r\n{\r\n    // You can get a list of valid parameters to config the session from https://github.com/cloudera/livy#request-body.\r\n    "driverMemory":\r\n    {\r\n        "activityParameterName": "driverMemoryParameter", \r\n        "defaultValue": "56g"\r\n    }, // Recommended values: ["28g", "56g", "112g", "224g", "400g", "472g"]\r\n    "driverCores":{\r\n        "activityParameterName": "driverCoresParameter", \r\n        "defaultValue": 8\r\n    }, // Recommended values: [4, 8, 16, 32, 64, 80]\r\n    "executorMemory":{\r\n        "activityParameterName": "executorMemoryParameter", \r\n        "defaultValue": "56g" \r\n    },\r\n    "executorCores":{\r\n        "activityParameterName": "executorCoresParameter", \r\n        "defaultValue": 8 \r\n    },\r\n    "numExecutors":{\r\n        "activityParameterName": "numExecutorsParameter", \r\n        "defaultValue": 3\r\n    }\r\n}\n')


# In[ ]:


get_ipython().run_cell_magic('spark', '', '%run /code/aurora/common/CreateHCMGlobalView\n')


# In[ ]:


get_ipython().run_cell_magic('spark', '', 'import scala.collection.mutable.ArrayBuffer\r\nval hcmLakeTables =  ArrayBuffer[(String, String, String)]()\r\n\r\n\r\n\r\nhcmLakeTables += (("HC01", "HC01OrgBusiness", "HC01OrgBusiness_hrcview"))\r\nhcmLakeTables += (("HC01", "HC01Position", "HC01Position_hrcview"))\r\nhcmLakeTables += (("HC01", "HCH01PersonHistory", "HCH01PersonHistory_hrcview" ))\r\nhcmLakeTables += (("HC01", "HC01PersonPosition", "HC01PersonPosition_hrcview" ))\r\nhcmLakeTables += (("HC01", "HC01Person", "HC01Person_hrcview" ))\r\nhcmLakeTables += (("HC01", "HC01StandardTitle", "HC01StandardTitle_hrcview" ))\r\nhcmLakeTables += (("HC01", "HC01StaffingResourceType", "HC01StaffingResourceType_hrcview" ))\r\nhcmLakeTables += (("HC01", "HC01StateProvince", "HC01StateProvince_hrcview" ))\r\nhcmLakeTables += (("HC01", "HCH01AddressBookTitleHistory", "HCH01AddressBookTitleHistory_hrcview" ))\r\nhcmLakeTables += (("HC01", "HC01EmployeeS", "HC01EmployeeS_hrcview" ))\r\nhcmLakeTables += (("HC01", "HC01Country", "HC01Country_hrcview" ))\r\nhcmLakeTables += (("HC01", "HC01Employee", "HC01Employee_hrcview" ))\r\nhcmLakeTables += (("HC01", "HC01EmployeePosition", "HC01EmployeePosition_hrcview" ))\r\n\r\nhcmLakeTables += (("EC/PersonnelData", "PersonnelData", "PersonnelData_hrcview" ))\r\nhcmLakeTables += (("EC/PersonalInformation", "PersonalInformation", "PersonalInformation_hrcview" ))\r\nhcmLakeTables += (("EC/JobInformation", "JobInformation", "JobInformation_hrcview" ))\r\nhcmLakeTables += (("EC/ProfilePosition", "ProfilePosition", "ProfilePosition_hrcview" ))\r\nhcmLakeTables += (("EC/Events", "Events", "Events_hrcview" ))\r\nhcmLakeTables += (("EC/EmploymentInformation", "EmploymentInformation", "EmploymentInformation_hrcview" ))\r\nhcmLakeTables += (("EC/Onboarding", "Onboarding", "Onboarding_hrcview" ))\r\nhcmLakeTables += (("EC/HybridWorkplace", "HybridWorkplace", "HybridWorkplace_hrcview" ))\r\nhcmLakeTables += (("EC/HybridWorkplaceConfirmation", "HybridWorkplaceConfirmation", "HybridWorkplaceConfirmation_hrcview" ))\r\nhcmLakeTables += (("EC/HybridWorkplacePeriod", "HybridWorkplacePeriod", "HybridWorkplacePeriod_hrcview" ))\r\nhcmLakeTables += (("EC/HybridWorkplaceConfirmationStatus", "HybridWorkplaceConfirmationStatus", "HybridWorkplaceConfirmationStatus_hrcview" ))\r\n\r\nhcmLakeTables += (("EC/Workflow", "Workflow", "Workflow_hrcview" ))\r\nhcmLakeTables += (("EC/Workflow", "WorkflowStep", "WorkflowStep_hrcview" ))\r\nhcmLakeTables += (("EC/Workflow", "WorkflowStepAssignment", "WorkflowStepAssignment_hrcview" ))\r\nhcmLakeTables += (("EC/Workflow", "WorkflowComment", "WorkflowComment_hrcview" ))\r\nhcmLakeTables += (("EC/Workflow", "WorkflowChangedData", "WorkflowChangedData_hrcview" ))\r\n\r\nhcmLakeTables += (("MSPEOPLE", "CostCenter", "CostCenter_hrcview" ))\r\nhcmLakeTables += (("MSPEOPLE", "Company", "Company_hrcview" ))\r\nhcmLakeTables += (("MSPEOPLE", "BuildingAddress", "BuildingAddress_hrcview"))\r\nhcmLakeTables += (("MSPEOPLE", "StateProvince", "StateProvince_hrcview" ))\r\nhcmLakeTables += (("MSPEOPLE", "DirectReportHierarchy", "DirectReportHierarchy_hrcview" ))\r\nhcmLakeTables += (("MSPEOPLE", "Country", "Country_hrcview" ))\r\n\r\nhcmLakeTables += (("EC/Domain", "State", "ECState_hrcview"))\r\nhcmLakeTables += (("EC/Domain", "Country", "ECCountry_hrcview"))\r\nhcmLakeTables += (("EC/AddressInformation", "AddressInformation", "AddressInformation_hrcview" ))\r\n\r\n\r\nhcmLakeTables += (("EC/Position", "PositionDetail", "positiondetail_hrcview" ))\r\nhcmLakeTables += (("EC/Position", "PositionJobTitleTaxonomy", "jobtitletaxonomy_hrcview" ))\r\nhcmLakeTables += (("EC/Position", "PositionPayScale", "PositionPayScale_hrcview" ))\r\nhcmLakeTables += (("EC/Position", "PositionChangeDetails", "positionchangedetails_hrcview" ))\r\nhcmLakeTables += (("EC/Position", "PositionJobTitleTaxonomy", "jobtitletaxonomy_hrcview" ))\r\nhcmLakeTables += (("MPHR", "AreaA14RegionTimezoneMapping", "Area14_hrcview" ))\r\n\r\nhcmLakeTables += (("HCWH", "RecruitingApplicationActivity", "RecruitingApplicationActivity_hrcview" ))\r\n\r\nval hcmEntities = hcmLakeTables.mkString(";")\r\ncreateGlobalView(hcmEntities)\n')


# In[ ]:


pipeline = "aurora_gold"

# By default, state is an empty string
# If running from notebook, state will be set to start by default. If running from pipeline, state will be set to restart by default
# To explicitly start or restart, state can be set to "start" or "restart" value
state = ""

# triggerType and runID are variables set by the pipeline. No need to pass any parameter from the user side 
triggerType = ""
runID = ""


# In[ ]:


# By default threads is set equal to the number of executor cores. "threads" variable can be tuned to a particular number depending on requirements
import os
threads = (sc._jsc.sc().getExecutorMemoryStatus().keySet().size()-1)*os.cpu_count() 


# In[ ]:


get_ipython().run_line_magic('run', '/code/parallel/GenieProcessExecution')


# In[ ]:


obj = Genie(threads)


# ### Uncomment below box to see Metadata graph

# In[ ]:


# # if not present in requirements.yml file for pool, run the following commands, otherwise proceed to the next cell
# conda install -y graphviz 
# pip install pydot
# pip install graphviz


# In[ ]:


# import graphviz
# import pydot
# from IPython.display import display

# st = GenieMetadataHelper()
# obj.metadatarows = st.getStorageMetaData(pipeline,state)
# obj.initializeGraph()
# graph = nx.drawing.nx_pydot.to_pydot(obj.graph)
# graph.set_rankdir("LR")
# gvz=graphviz.Source(graph.to_string())
# display(gvz)


# In[ ]:


obj.execute(state,pipeline,runID,triggerType)


# In[ ]:


mssparkutils.notebook.exit("")


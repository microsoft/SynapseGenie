#!/usr/bin/env python
# coding: utf-8

# ## GenieMetadata
# 
# 
# 

# In[13]:


from dataclasses import dataclass

@dataclass
class GenieMetadata:
    notebookid: str
    notebookname: str
    Dependencies: str
    Type: str
    status: str
    notebookparams: str


# In[14]:


class GenieMetadataHelper:
    def metaDataParser(self, collection):
     return  [metadata(row['notebookid'],row['notebookname'],row['Dependencies'],row['Type'],row['status'],row['notebookparams']) for row in collection]
     
    def getStorageMetaData(self, pipelineName):
        collection = spark.sql(f"""Select nb.notebookid,nb.notebookname,nb.Dependencies,nb.Type,l.status,nb.notebookparams from parallel.notebook nb
                        left join (SELECT notebook,status,
                                    ROW_NUMBER() OVER (PARTITION BY notebook ORDER BY cast(start as timestamp) DESC) ranked_order
                        FROM parallel.log ) l
                        on nb.notebookid = l.notebook and l.ranked_order = 1
                        WHERE nb.isActive=1 and nb.pipeline='{pipelineName}' 
                        """).collect()
        metaDataRows = self.metaDataParser(collection)
        return metaDataRows

